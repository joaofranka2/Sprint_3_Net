﻿using CurriculoAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface ICurriculoService
{
    Task<IEnumerable<Curriculo>> GetAllAsync();
    Task<Curriculo> GetByIdAsync(int id);
    Task AddAsync(Curriculo curriculo);
    Task UpdateAsync(Curriculo curriculo);
    Task DeleteAsync(int id);

    // Método de paginação adicionado à interface
    Task<IEnumerable<Curriculo>> GetAllPagedAsync(int pageNumber, int pageSize);
}
