﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CurriculoAPI.Models;

public interface ICurriculoService
{
    Task<IEnumerable<Curriculo>> GetAllAsync();
    Task<Curriculo> GetByIdAsync(int id);
    Task AddAsync(Curriculo curriculo);
    Task UpdateAsync(Curriculo curriculo);
    Task DeleteAsync(int id);
}
