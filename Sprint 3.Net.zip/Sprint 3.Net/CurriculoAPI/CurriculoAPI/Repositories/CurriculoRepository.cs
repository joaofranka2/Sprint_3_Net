﻿using CurriculoAPI.Data; // Adicione esta linha
using CurriculoAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

public class CurriculoRepository : ICurriculoRepository
{
    private readonly AppDbContext _context;
    private readonly ILogger<CurriculoRepository> _logger;

    public CurriculoRepository(AppDbContext context, ILogger<CurriculoRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

   

public async Task<IEnumerable<Curriculo>> GetAllAsync()
    {
        try
        {
            _logger.LogInformation("Iniciando a busca de todos os currículos.");
            var curriculos = await _context.Curriculos.AsNoTracking().ToListAsync();
            _logger.LogInformation("Busca de todos os currículos concluída com sucesso. {Count} currículos encontrados.", curriculos.Count);
            return curriculos;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao buscar todos os currículos.");
            throw;
        }
    }

    public async Task<Curriculo> GetByIdAsync(int id)
    {
        try
        {
            _logger.LogInformation("Iniciando a busca do currículo com ID: {Id}", id);
            var curriculo = await _context.Curriculos.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
            if (curriculo == null)
            {
                _logger.LogWarning("Currículo com ID: {Id} não encontrado.", id);
            }
            else
            {
                _logger.LogInformation("Currículo com ID: {Id} encontrado.", id);
            }
            return curriculo;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao buscar o currículo com ID: {Id}", id);
            throw;
        }
    }

    public async Task AddAsync(Curriculo curriculo)
    {
        try
        {
            _logger.LogInformation("Iniciando a adição de um novo currículo.");
            await _context.Curriculos.AddAsync(curriculo);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Currículo adicionado com sucesso. ID: {Id}", curriculo.Id);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Erro ao adicionar o currículo.");
            throw new Exception("Ocorreu um erro ao adicionar o currículo.", ex);
        }
    }

    public async Task UpdateAsync(Curriculo curriculo)
    {
        try
        {
            _logger.LogInformation("Iniciando a atualização do currículo com ID: {Id}", curriculo.Id);
            _context.Curriculos.Update(curriculo);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Currículo com ID: {Id} atualizado com sucesso.", curriculo.Id);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Erro ao atualizar o currículo com ID: {Id}", curriculo.Id);
            throw new Exception("Ocorreu um erro ao atualizar o currículo.", ex);
        }
    }

    public async Task DeleteAsync(int id)
    {
        try
        {
            _logger.LogInformation("Iniciando a exclusão do currículo com ID: {Id}", id);
            var curriculo = await GetByIdAsync(id);
            if (curriculo != null)
            {
                _context.Curriculos.Remove(curriculo);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Currículo com ID: {Id} excluído com sucesso.", id);
            }
            else
            {
                _logger.LogWarning("Tentativa de exclusão falhou. Currículo com ID: {Id} não encontrado.", id);
            }
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Erro ao excluir o currículo com ID: {Id}", id);
            throw new Exception("Ocorreu um erro ao excluir o currículo.", ex);
        }
    }

    // Implementação do método de paginação
    public async Task<IEnumerable<Curriculo>> GetAllPagedAsync(int pageNumber, int pageSize)
    {
        try
        {
            _logger.LogInformation("Iniciando a busca de currículos paginada. Página: {PageNumber}, Tamanho da Página: {PageSize}", pageNumber, pageSize);
            var curriculos = await _context.Curriculos.AsNoTracking()
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            _logger.LogInformation("Busca de currículos paginada concluída. Página: {PageNumber}, Tamanho da Página: {PageSize}, {Count} currículos encontrados.", pageNumber, pageSize, curriculos.Count);
            return curriculos;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao buscar currículos com paginação. Página: {PageNumber}, Tamanho da Página: {PageSize}", pageNumber, pageSize);
            throw;
        }
    }
}
