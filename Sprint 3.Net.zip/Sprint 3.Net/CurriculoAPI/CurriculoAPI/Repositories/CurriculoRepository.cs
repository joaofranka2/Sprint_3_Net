﻿using CurriculoAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

public class CurriculoRepository : ICurriculoRepository
{
    private readonly AppDbContext _context;

    public CurriculoRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Curriculo>> GetAllAsync()
    {
        return await _context.Curriculos.AsNoTracking().ToListAsync();
    }

    public async Task<Curriculo> GetByIdAsync(int id)
    {
        return await _context.Curriculos.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task AddAsync(Curriculo curriculo)
    {
        try
        {
            await _context.Curriculos.AddAsync(curriculo);
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateException ex)
        {
            // Log error (ex) here using a logger or throw a custom exception
            throw new Exception("An error occurred while adding the curriculum.", ex);
        }
    }

    public async Task UpdateAsync(Curriculo curriculo)
    {
        try
        {
            _context.Curriculos.Update(curriculo);
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateException ex)
        {
            // Log error (ex) here using a logger or throw a custom exception
            throw new Exception("An error occurred while updating the curriculum.", ex);
        }
    }

    public async Task DeleteAsync(int id)
    {
        var curriculo = await GetByIdAsync(id);
        if (curriculo != null)
        {
            try
            {
                _context.Curriculos.Remove(curriculo);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                // Log error (ex) here using a logger or throw a custom exception
                throw new Exception("An error occurred while deleting the curriculum.", ex);
            }
        }
    }
}
