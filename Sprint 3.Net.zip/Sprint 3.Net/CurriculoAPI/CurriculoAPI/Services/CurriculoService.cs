﻿using CurriculoAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

public class CurriculoService : ICurriculoService
{
    private readonly ICurriculoRepository _curriculoRepository;

    public CurriculoService(ICurriculoRepository curriculoRepository)
    {
        _curriculoRepository = curriculoRepository;
    }

    public async Task<IEnumerable<Curriculo>> GetAllAsync()
    {
        return await _curriculoRepository.GetAllAsync();
    }

    public async Task<Curriculo> GetByIdAsync(int id)
    {
        return await _curriculoRepository.GetByIdAsync(id);
    }

    public async Task AddAsync(Curriculo curriculo)
    {
        await _curriculoRepository.AddAsync(curriculo);
    }

    public async Task UpdateAsync(Curriculo curriculo)
    {
        await _curriculoRepository.UpdateAsync(curriculo);
    }

    public async Task DeleteAsync(int id)
    {
        await _curriculoRepository.DeleteAsync(id);
    }

    // Implementação do método de paginação
    public async Task<IEnumerable<Curriculo>> GetAllPagedAsync(int pageNumber, int pageSize)
    {
        return await _curriculoRepository.GetAllPagedAsync(pageNumber, pageSize);
    }
}

