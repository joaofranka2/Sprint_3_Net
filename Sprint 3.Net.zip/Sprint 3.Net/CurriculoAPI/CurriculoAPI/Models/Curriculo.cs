﻿using System.ComponentModel.DataAnnotations;

namespace CurriculoAPI.Models
{
    public class Curriculo
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório.")]
        [StringLength(100, ErrorMessage = "O nome não pode exceder 100 caracteres.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "O e-mail não é válido.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "A experiência profissional é obrigatória.")]
        public string ExperienciaProfissional { get; set; }
    }
}
