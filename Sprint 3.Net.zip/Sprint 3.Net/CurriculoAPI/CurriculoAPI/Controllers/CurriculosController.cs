﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using CurriculoAPI.Models;

[Route("api/[controller]")]
[ApiController]
public class CurriculosController : ControllerBase
{
    private readonly ICurriculoService _curriculoService;

    public CurriculosController(ICurriculoService curriculoService)
    {
        _curriculoService = curriculoService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Curriculo>>> GetAll()
    {
        var curriculos = await _curriculoService.GetAllAsync();
        return Ok(curriculos);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Curriculo>> GetById(int id)
    {
        var curriculo = await _curriculoService.GetByIdAsync(id);
        if (curriculo == null)
        {
            return NotFound();
        }
        return Ok(curriculo);
    }

    [HttpPost]
    public async Task<ActionResult> Add([FromBody] Curriculo curriculo)
    {
        await _curriculoService.AddAsync(curriculo);
        return CreatedAtAction(nameof(GetById), new { id = curriculo.Id }, curriculo);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] Curriculo curriculo)
    {
        if (id != curriculo.Id)
        {
            return BadRequest();
        }

        await _curriculoService.UpdateAsync(curriculo);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _curriculoService.DeleteAsync(id);
        return NoContent();
    }
}
