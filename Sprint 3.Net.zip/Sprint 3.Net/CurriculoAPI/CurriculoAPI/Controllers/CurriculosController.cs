﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using CurriculoAPI.Models;
using Microsoft.Extensions.Logging;

[Route("api/[controller]")]
[ApiController]
public class CurriculosController : ControllerBase
{
    private readonly ICurriculoService _curriculoService;
    private readonly ILogger<CurriculosController> _logger;

    public CurriculosController(ICurriculoService curriculoService, ILogger<CurriculosController> logger)
    {
        _curriculoService = curriculoService;
        _logger = logger;
    }

    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<IEnumerable<Curriculo>>> GetAll()
    {
        _logger.LogInformation("Iniciando a busca de todos os currículos.");
        try
        {
            var curriculos = await _curriculoService.GetAllAsync();
            _logger.LogInformation("Busca de todos os currículos concluída com sucesso.");
            return Ok(curriculos);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao buscar todos os currículos.");
            return StatusCode(500, "Ocorreu um erro ao buscar os currículos.");
        }
    }

    [HttpGet("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<Curriculo>> GetById(int id)
    {
        _logger.LogInformation("Iniciando a busca do currículo com ID: {Id}", id);
        try
        {
            var curriculo = await _curriculoService.GetByIdAsync(id);
            if (curriculo == null)
            {
                _logger.LogWarning("Currículo com ID: {Id} não encontrado.", id);
                return NotFound();
            }

            _logger.LogInformation("Currículo com ID: {Id} encontrado.", id);
            return Ok(curriculo);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao buscar o currículo com ID: {Id}", id);
            return StatusCode(500, "Ocorreu um erro ao buscar o currículo.");
        }
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult> Add([FromBody] Curriculo curriculo)
    {
        _logger.LogInformation("Iniciando a adição de um novo currículo.");

        if (!ModelState.IsValid)
        {
            _logger.LogWarning("Tentativa de adicionar um currículo com dados inválidos.");
            return BadRequest(ModelState);
        }

        try
        {
            await _curriculoService.AddAsync(curriculo);
            _logger.LogInformation("Currículo adicionado com sucesso. ID: {Id}", curriculo.Id);
            return CreatedAtAction(nameof(GetById), new { id = curriculo.Id }, curriculo);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao adicionar um novo currículo.");
            return StatusCode(500, "Ocorreu um erro ao adicionar o currículo.");
        }
    }

    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> Update(int id, [FromBody] Curriculo curriculo)
    {
        if (id != curriculo.Id)
        {
            _logger.LogWarning("ID do currículo no caminho ({IdPath}) não corresponde ao ID do currículo no corpo ({IdBody}).", id, curriculo.Id);
            return BadRequest();
        }

        _logger.LogInformation("Iniciando a atualização do currículo com ID: {Id}", id);
        try
        {
            await _curriculoService.UpdateAsync(curriculo);
            _logger.LogInformation("Currículo com ID: {Id} atualizado com sucesso.", id);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao atualizar o currículo com ID: {Id}", id);
            return StatusCode(500, "Ocorreu um erro ao atualizar o currículo.");
        }
    }

    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> Delete(int id)
    {
        _logger.LogInformation("Iniciando a exclusão do currículo com ID: {Id}", id);
        try
        {
            await _curriculoService.DeleteAsync(id);
            _logger.LogInformation("Currículo com ID: {Id} excluído com sucesso.", id);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao excluir o currículo com ID: {Id}", id);
            return StatusCode(500, "Ocorreu um erro ao excluir o currículo.");
        }
    }

    [HttpGet("paged")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<IEnumerable<Curriculo>>> GetAllPaged(int pageNumber = 1, int pageSize = 10)
    {
        _logger.LogInformation("Iniciando a busca de currículos com paginação. Página: {PageNumber}, Tamanho da Página: {PageSize}", pageNumber, pageSize);

        if (pageNumber <= 0 || pageSize <= 0)
        {
            _logger.LogWarning("Parâmetros de paginação inválidos. Página: {PageNumber}, Tamanho da Página: {PageSize}", pageNumber, pageSize);
            return BadRequest("Os parâmetros de paginação devem ser maiores que zero.");
        }

        try
        {
            var curriculos = await _curriculoService.GetAllPagedAsync(pageNumber, pageSize);
            _logger.LogInformation("Busca de currículos com paginação concluída. Página: {PageNumber}, Tamanho da Página: {PageSize}");
            return Ok(curriculos);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao buscar currículos com paginação.");
            return StatusCode(500, "Ocorreu um erro ao buscar os currículos paginados.");
        }
    }
}
